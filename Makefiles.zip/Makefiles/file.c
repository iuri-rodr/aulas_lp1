
#include <stdio.h>

#define IPCA "Instituto Politécnico do Cávado e do Ave"

int main() {
	printf("Escrevi algo....\n");
	printf("%s\n",IPCA);
}
