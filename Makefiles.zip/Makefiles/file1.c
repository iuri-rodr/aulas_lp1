/*
 * lufer
 * lufer@ipca.pt
 * file1.c
 */

#include <stdio.h>

void main()
{
    printf("main() run!\n");
    myFunc();
}
