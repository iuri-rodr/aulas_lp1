
/*
 * lufer
 * lufer@ipca.pt
 * file2.c
 */

#include <stdio.h>

void myfunc()
{
    printf("myfunc() run!\n");
}
